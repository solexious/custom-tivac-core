typedef struct {
  int  aPin;
  char aLabel[10];
  int  bPin;
  char bLabel[10];
} patch_t;

