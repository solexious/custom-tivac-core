typedef struct {
  int  aPin;
  char aLabel[50];
  int  bPin;
  char bLabel[50];
} patch_t;

