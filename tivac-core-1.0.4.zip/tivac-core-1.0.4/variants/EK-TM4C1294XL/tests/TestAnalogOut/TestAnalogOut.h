typedef struct {
  char portLabel[10];
  char x11Label[10];
  int  portpin;
} analogoutpin_t;

